import React from 'react'
import { render } from 'utils/testUtil';
import Loading from 'components/common/Loading';

it('renders Loading component', () => {
  render(<Loading />);
});
